package pp.mvc.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

class ListDAO{
   DataSource ds;
   Statement stmt,stmt2;
   PreparedStatement pstmt,pstmt2;
   ListDAO(){
      try {
         Context initContext = new InitialContext();
         Context envContext = (Context)initContext.lookup("java:/comp/env");
         ds = (DataSource)envContext.lookup("jdbc/myoracle");
      }catch(NamingException ne) {   
         System.out.println(ne+"listDAO");
      }
      
   }
   ArrayList<ListDTO> list(String loc, String sex,HttpServletRequest request, HttpServletResponse response){
      ArrayList<ListDTO>list = new ArrayList<ListDTO>();
      Connection con = null;
      HttpSession session = request.getSession();
      //String sessionSex=(String)session.getAttribute("sex");
      //String sessionLoc=(String)session.getAttribute("loc");
      //System.out.println(sessionSex);
      //if(sessionSex!=null)sex=sessionSex;
      //if(sessionLoc!=null)loc=sessionLoc;
      
      ResultSet rs,rs2,rs4,rs5;
      ResultSet rs3 = null;
      PreparedStatement pstmt=null;
      int i = 0;
      int intLoc=0;
      String location = null;
      String id =null;
      
      try {
         con = ds.getConnection();
         stmt = con.createStatement();
         
         
         rs = stmt.executeQuery(ListSQL.ID);   
         Boolean flag =true;
         ListDTO dto = null;
         
         while(rs.next()==true){
            
            id = rs.getString(1);
            pstmt = con.prepareStatement(ListSQL.SITTERINFO);

            pstmt.setString(1, id);
            pstmt.setString(2, id);
            rs2 = pstmt.executeQuery();
            
            
            
            
            flag =rs2.next();
            
      
               
            i++;
            
            if(flag==false)
               continue;
            int locNo = rs2.getInt(2);
            String name = rs2.getString(3);
            String address = rs2.getString(8);
            String petNum = rs2.getString(10);
            String fName = rs2.getString(13);
            String jDate = rs2.getString(15);
         
            String career = rs2.getString(16);
            
            if(loc==null) {
               pstmt = con.prepareStatement(ListSQL.LOCATION);
               pstmt.setInt(1,locNo);
               rs3 = pstmt.executeQuery();
               rs3.next();
               location = rs3.getString(1);
            }
            
            
            
            pstmt2 = con.prepareStatement(ListSQL.PETFILENAME);
            pstmt2.setString(1,id);
            rs4 = pstmt2.executeQuery();
            String petFileName = null;
            if(rs4.next())
               petFileName = rs4.getString(1);
            else
            petFileName="null.jpg";
            
            if(fName==null)fName="null.jpg";
            else if(petFileName==null)petFileName="null2.jpg";
            if(sex!=null&&loc!=null) {
               if(sex.equals(rs2.getString(9))&&Integer.parseInt(loc)==(locNo)) {
                     System.out.println("DASDSADSADSADSA");
                  dto= new ListDTO(id,address,location,name,fName,jDate,petNum,petFileName,career);
                  list.add(dto);
                  session.setAttribute("sex", sex);
                  session.setAttribute("loc", loc);
               }
            }else {
               System.out.println("DASDSADSADSADSA321321321321321");
               dto= new ListDTO(id,address,location,name,fName,jDate,petNum,petFileName,career);
               list.add(dto);
               
            }
         }
         
      
      }catch(SQLException se) {
      se.printStackTrace();
         System.out.println(se+"list error");
         return list;
      }
      return list;
   }
   String getTotalSitter() {
      Connection con = null;
      ResultSet rs = null;
      Statement stmt=null;
      String totalSitter;
      try {
         
         con = ds.getConnection();
         
         stmt = con.createStatement();
         
         rs = stmt.executeQuery(ListSQL.SITTER2);
         rs.next();
         totalSitter = rs.getString(1);
         
      }catch(SQLException se) {
         System.out.println(se+"total sitter");
         return "error";
      }
      
      return totalSitter;
   }   
   String getSitterNumber(HttpServletRequest request, HttpServletResponse response) {
      Connection con = null;
      ResultSet rs = null;
      PreparedStatement pstmt=null;
      String totalSitter = null;
      try {
         con = ds.getConnection();
         String location = request.getParameter("location");
         String sex = request.getParameter("sex");
         
         int intLoc= 0;
         System.out.println("loc"+location);
         System.out.println(location);
         System.out.println(location);
         System.out.println(location);
         
         if(location==null) {
            
            System.out.println("loc null");
            if(sex==null) {
               System.out.println("sex null");
//               pstmt = con.prepareStatement(ListSQL.TOTALSITTER);
//               rs=pstmt.executeQuery();
//               rs.next();
               totalSitter = getTotalSitter();
               
            }
            else {
               System.out.println("else2");
            pstmt = con.prepareStatement(ListSQL.TOTALSITTER2);
            
            pstmt.setString(1,sex);
            rs=pstmt.executeQuery();
            rs.next();
            totalSitter = rs.getString(1);
            }
         }
         else {
            System.out.println("els2222222e");
//            pstmt.setInt(1,Integer.parseInt(location));
//            rs=pstmt.executeQuery();
//            rs.next();
//            totalSitter = rs.getString(1);
         }
         if(sex!=null&&location!=null)
         {   
            System.out.println(location+"location");
            System.out.println(location+"location");
            System.out.println(location+"location");
            System.out.println(location+"location");
            System.out.println(location+"location");
            pstmt = con.prepareStatement(ListSQL.TOTALSITTER);
            pstmt.setInt(1,Integer.parseInt(location));
            pstmt.setString(2,sex);
            rs=pstmt.executeQuery();
            rs.next();
            totalSitter = rs.getString(1);
         }
         
         System.out.println("totallsitterL:"+totalSitter);
         System.out.println("totallsitterL:"+totalSitter);
         System.out.println("totallsitterL:"+totalSitter);
         System.out.println("totallsitterL:"+totalSitter);
         System.out.println("totallsitterL:"+totalSitter);
         System.out.println("totallsitterL:"+totalSitter);
         
      }catch(SQLException se) {
         System.out.println(se+"total sitter");
         return "error";
      }
      
      return totalSitter;
   }   
   SitterDTO2 getSitterInfo(String id) {
      Connection con = null;
      ResultSet rs = null;
      PreparedStatement pstmt = null;
      ArrayList<SitterDTO2> list = null;
      SitterDTO2 dtoOG = null;
      try {
         
         con = ds.getConnection();
         pstmt = con.prepareStatement(ListSQL.SITTERINFO);
         pstmt.setString(1,id);
         pstmt.setString(2,id);
         rs = pstmt.executeQuery();
         rs.next();
         String identification = rs.getString(1);
         String locNo =rs.getString(2);
         String name = rs.getString(3);
         String phone = rs.getString(4);
         String pw = rs.getString(5);
         String email = rs.getString(6);
         String birth =rs.getString(7);
         String addr =rs.getString(8);
         String sex = rs.getString(9);
         String petNum =rs.getString(10);
         String serviceNum = rs.getString(11);
         String jDate = rs.getString(12);
         String fName =rs.getString(13);
         String fSize =rs.getString(14);
         String jDate2 = rs.getString(15);
         String career = rs.getString(16);
         String grade = rs.getString(17);
         String info = rs.getString(18);
         
         pstmt = con.prepareStatement(ListSQL.LOCATION);
         
         pstmt.setString(1,locNo);
         rs = pstmt.executeQuery();
         rs.next();
         String location = rs.getString(1);
         dtoOG = new SitterDTO2(identification,location,birth,serviceNum,jDate2,fName,career,grade,info);
         ArrayList<SitterDTO2> dto = new ArrayList<SitterDTO2>();
         dto.add(dtoOG);
         return dtoOG;
      
      
      }catch(SQLException se) {
      System.out.println(se+" sitter info");
         return null;
      }
   
   
   }
}